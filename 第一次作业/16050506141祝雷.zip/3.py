m = float(input("电阻数量："))
a = float(input("输入电阻值："))
print (a/m);