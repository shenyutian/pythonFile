def bookprice(price, weight, postage, rate, number):
	smax = price*number*rate + weight*number*postage
	return "总共要收你", smax, "元"

price = float(input("输入书籍单价元："))
weight = float(input("输入一本书的重量公斤："))
postage = float(input("输入邮费每公斤/元："))
rate = float(input("输入打折率 ： "))
number = float(input("输入书本数量 本 ："))
print (bookprice(price, weight, postage, rate, number))